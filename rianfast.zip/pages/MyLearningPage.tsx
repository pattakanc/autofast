
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import type { Course } from '../types';
import { getCourses } from '../services/courseService';
import Spinner from '../components/ui/Spinner';
import Button from '../components/ui/Button';
import { useCart } from '../contexts/CartContext'; // Import useCart

const MyLearningPage: React.FC = () => {
  const [enrolledCourses, setEnrolledCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { purchasedCourseIds } = useCart(); // Get purchasedCourseIds from context

  useEffect(() => {
    const fetchEnrolledCourses = async () => {
      setLoading(true);
      try {
        const allCourses = await getCourses(); // Fetch all available courses
        // Filter courses to include only those whose IDs are in purchasedCourseIds
        const userPurchasedCourses = allCourses.filter(course =>
          purchasedCourseIds.includes(course.id)
        );
        setEnrolledCourses(userPurchasedCourses);
      } catch (error) {
        console.error("Error fetching or filtering enrolled courses:", error);
        setEnrolledCourses([]); // Set to empty on error
      } finally {
        setLoading(false);
      }
    };

    fetchEnrolledCourses();
  }, [purchasedCourseIds]); // Re-run effect if purchasedCourseIds changes

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <section className="bg-white p-6 rounded-lg shadow">
        <h1 className="text-3xl font-semibold text-gray-800 mb-4">My Learning</h1>
        <p className="text-gray-600">
          Continue your learning journey. Here are the courses you've purchased.
        </p>
      </section>

      {enrolledCourses.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {enrolledCourses.map(course => (
            <div key={course.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
                <Link to={`/courses/${course.id}`} className="block">
                    <img 
                    src={`${course.thumbnailUrl}?seed=${course.id}-mylearning`} 
                    alt={course.title} 
                    className="w-full h-48 object-cover" 
                    />
                </Link>
                <div className="p-4">
                    <Link to={`/courses/${course.id}`} className="block">
                        <h3 className="text-lg font-semibold text-gray-800 hover:text-primary transition-colors truncate">{course.title}</h3>
                    </Link>
                    <p className="text-sm text-gray-500 mt-1">{course.instructor.name}</p>
                    {/* Example Progress Bar (static for demo, could be enhanced if progress is tracked) */}
                    <div className="mt-3">
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                            {/* Static progress for demo, ideally this would be dynamic */}
                            <div className="bg-primary h-2.5 rounded-full" style={{ width: `75%` }}></div> 
                        </div>
                        <p className="text-xs text-gray-500 mt-1 text-right">75% complete (demo)</p>
                    </div>
                    <Button 
                        variant="primary" 
                        className="mt-4 w-full text-sm py-2"
                        onClick={() => navigate(`/courses/${course.id}`)}
                    >
                        Resume Learning
                    </Button>
                </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <h2 className="text-2xl font-semibold text-gray-700 mb-2">You Haven't Purchased Any Courses Yet</h2>
          <p className="text-gray-500 mb-6">Start your learning journey by exploring our wide range of courses and making a purchase.</p>
          <Button onClick={() => navigate('/courses')}>
            Explore Courses
          </Button>
        </div>
      )}
    </div>
  );
};

export default MyLearningPage;
