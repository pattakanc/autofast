
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import type { CartItem } from '../contexts/CartContext';
import Button from '../components/ui/Button';
import { IconShoppingCart, IconX, IconCheckCircle } from '../constants';
import { useCurrency } from '../contexts/CurrencyContext';
import Spinner from '../components/ui/Spinner'; // Import Spinner

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, getCartTotal, getCartItemCount, clearCart, recordPurchase } = useCart();
  const { formatPrice } = useCurrency();
  const navigate = useNavigate();
  const [checkoutStatus, setCheckoutStatus] = useState<'idle' | 'processing' | 'success'>('idle');

  const handleRemoveItem = (courseId: string) => {
    removeFromCart(courseId);
  };

  const handleCheckout = () => {
    setCheckoutStatus('processing'); // Set to processing state
    console.log("Proceeding to checkout with items:", cartItems);

    // Simulate payment processing
    setTimeout(() => {
      recordPurchase(cartItems); 
      clearCart();
      setCheckoutStatus('success');
    }, 2500); // Simulate 2.5 seconds delay
  };

  if (checkoutStatus === 'success') {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow-md">
        <IconCheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h1 className="text-2xl font-semibold text-gray-700 mb-2">Thank You for Your Purchase!</h1>
        <p className="text-gray-500 mb-6">Your order has been placed successfully. You can find your new courses in "My Learning".</p>
        <div className="flex justify-center space-x-4">
          <Button onClick={() => navigate('/my-learning')} variant="secondary" size="lg">
            Go to My Learning
          </Button>
          <Button onClick={() => navigate('/courses')} variant="primary" size="lg">
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  if (getCartItemCount() === 0 && checkoutStatus === 'idle') { // Ensure this doesn't show during processing
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow-md">
        <IconShoppingCart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h1 className="text-2xl font-semibold text-gray-700 mb-2">Your Cart is Empty</h1>
        <p className="text-gray-500 mb-6">Looks like you haven't added any courses to your cart yet.</p>
        <Button onClick={() => navigate('/courses')} variant="primary" size="lg">
          Explore Courses
        </Button>
      </div>
    );
  }
  
  const cartTotalInUSD = getCartTotal();

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-semibold text-gray-800 mb-8">Shopping Cart</h1>
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Cart Items List */}
        <div className="lg:w-2/3 space-y-4">
          {cartItems.map((item: CartItem) => (
            <div key={item.id} className="bg-white p-4 rounded-lg shadow-md flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <img 
                src={`${item.thumbnailUrl}?seed=${item.id}-cart`} 
                alt={item.title} 
                className="w-full sm:w-32 h-auto sm:h-20 object-cover rounded-md flex-shrink-0"
              />
              <div className="flex-grow">
                <Link to={`/courses/${item.id}`} className="hover:text-primary">
                  <h2 className="text-lg font-semibold text-gray-800 ">{item.title}</h2>
                </Link>
                <p className="text-sm text-gray-500">By {item.instructor.name}</p>
              </div>
              <div className="flex flex-col sm:flex-row items-start sm:items-center sm:space-x-4 w-full sm:w-auto mt-2 sm:mt-0">
                <p className="text-lg font-semibold text-primary sm:min-w-[80px] text-left sm:text-right">
                  {formatPrice(item.price)}
                </p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleRemoveItem(item.id)}
                  className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1 mt-2 sm:mt-0"
                  aria-label={`Remove ${item.title} from cart`}
                  disabled={checkoutStatus === 'processing'} // Disable remove button during processing
                >
                  <IconX className="w-5 h-5" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:w-1/3 space-y-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Order Summary</h2>
            <div className="space-y-2">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal ({getCartItemCount()} item{getCartItemCount() !== 1 ? 's' : ''}):</span>
                <span>{formatPrice(cartTotalInUSD)}</span>
              </div>
              {/* Add discounts, taxes etc. here if needed */}
              <div className="flex justify-between text-xl font-bold text-gray-800 pt-2 border-t mt-2">
                <span>Total:</span>
                <span>{formatPrice(cartTotalInUSD)}</span>
              </div>
            </div>
            <Button 
              variant="primary" 
              size="lg" 
              fullWidth 
              className="mt-6"
              onClick={handleCheckout}
              disabled={checkoutStatus === 'processing' || getCartItemCount() === 0}
              leftIcon={checkoutStatus === 'processing' ? <Spinner size="sm" color="text-white"/> : null}
            >
              {checkoutStatus === 'processing' ? 'Processing Payment...' : 'Proceed to Checkout'}
            </Button>
            {checkoutStatus !== 'processing' && ( // Hide guarantee message during processing if desired
                <p className="text-xs text-gray-500 text-center mt-2">
                    30-Day Money-Back Guarantee on all courses.
                </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
