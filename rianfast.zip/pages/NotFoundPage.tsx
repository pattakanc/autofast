
import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/ui/Button';

const NotFoundPage: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] text-center px-4">
      <img 
        src="https://picsum.photos/seed/404page/400/300" 
        alt="Lost and Confused" 
        className="w-64 h-auto rounded-lg shadow-lg mb-8"
      />
      <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
      <h2 className="text-3xl font-semibold text-gray-800 mb-3">Oops! Page Not Found.</h2>
      <p className="text-gray-600 mb-8 max-w-md">
        The page you're looking for doesn't seem to exist. It might have been moved, deleted, or maybe you just mistyped the URL.
      </p>
      <Button size="lg" onClick={() => window.location.hash = '/'}>
        Go to Homepage
      </Button>
    </div>
  );
};

export default NotFoundPage;
