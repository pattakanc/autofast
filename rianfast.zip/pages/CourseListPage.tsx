
import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import type { Course, Category } from '../types';
import { getCourses, getCategories } from '../services/courseService';
import CourseCard from '../components/ui/CourseCard';
import Spinner from '../components/ui/Spinner';
import { IconChevronDown, categoriesList } from '../constants';
import SearchBar from '../components/ui/SearchBar';

const CourseListPage: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [allCategories, setAllCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();

  const currentCategorySlug = useMemo(() => searchParams.get('category') || '', [searchParams]);
  const currentSearchTerm = useMemo(() => searchParams.get('search') || '', [searchParams]);
  const [currentSort, setCurrentSort] = useState(searchParams.get('sort') || 'relevance');
  
  const [filterDropdownOpen, setFilterDropdownOpen] = useState<string | null>(null);


  useEffect(() => {
    const fetchPageData = async () => {
      setLoading(true);
      try {
        const [coursesData, categoriesData] = await Promise.all([
          getCourses(currentCategorySlug, currentSearchTerm),
          getCategories()
        ]);
        
        // Apply client-side sorting for now
        let sortedCourses = [...coursesData];
        if (currentSort === 'rating') {
          sortedCourses.sort((a, b) => b.rating - a.rating);
        } else if (currentSort === 'price-asc') {
          sortedCourses.sort((a, b) => a.price - b.price);
        } else if (currentSort === 'price-desc') {
          sortedCourses.sort((a, b) => b.price - a.price);
        }
        // 'relevance' is default from service or search term based

        setCourses(sortedCourses);
        setAllCategories(categoriesData);
      } catch (error) {
        console.error("Error fetching courses:", error);
        setCourses([]); // Set to empty array on error
      } finally {
        setLoading(false);
      }
    };

    fetchPageData();
  }, [currentCategorySlug, currentSearchTerm, currentSort]);

  const handleCategoryChange = (slug: string) => {
    setSearchParams(prev => {
      if (slug === '') {
        prev.delete('category');
      } else {
        prev.set('category', slug);
      }
      return prev;
    });
    setFilterDropdownOpen(null);
  };
  
  const handleSearch = (query: string) => {
     setSearchParams(prev => {
      if (query === '') {
        prev.delete('search');
      } else {
        prev.set('search', query);
      }
      return prev;
    });
  };

  const handleSortChange = (sortValue: string) => {
    setCurrentSort(sortValue);
    setSearchParams(prev => {
      prev.set('sort', sortValue);
      return prev;
    });
    setFilterDropdownOpen(null);
  };

  const toggleFilterDropdown = (dropdownName: string) => {
    setFilterDropdownOpen(filterDropdownOpen === dropdownName ? null : dropdownName);
  };
  
  const selectedCategoryName = useMemo(() => {
    return allCategories.find(c => c.slug === currentCategorySlug)?.name || "All Categories";
  }, [allCategories, currentCategorySlug]);

  return (
    <div className="space-y-8">
      <section className="bg-gray-50 p-6 rounded-lg shadow">
        <h1 className="text-3xl font-semibold text-gray-800 mb-2">
          {currentSearchTerm ? `Search Results for "${currentSearchTerm}"` : selectedCategoryName}
        </h1>
        <p className="text-gray-600">
          {courses.length} course{courses.length !== 1 && 's'} found.
        </p>
        <div className="mt-4">
           <SearchBar onSearch={handleSearch} placeholder="Search within courses..." className="max-w-md"/>
        </div>
      </section>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters Sidebar */}
        <aside className="w-full md:w-1/4 lg:w-1/5 space-y-6">
          <div>
            <h3 className="text-xl font-semibold mb-3 text-gray-700">Categories</h3>
            <ul className="space-y-1">
              <li>
                <button
                  onClick={() => handleCategoryChange('')}
                  className={`w-full text-left px-3 py-2 rounded-md text-sm ${!currentCategorySlug ? 'bg-primary-light text-primary font-medium' : 'hover:bg-gray-100'}`}
                >
                  All Categories
                </button>
              </li>
              {allCategories.map(cat => (
                <li key={cat.id}>
                  <button
                    onClick={() => handleCategoryChange(cat.slug)}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm ${currentCategorySlug === cat.slug ? 'bg-primary-light text-primary font-medium' : 'hover:bg-gray-100'}`}
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Other filters can be added here: Price, Level, Duration, etc. */}
          <div>
            <h3 className="text-xl font-semibold mb-3 text-gray-700">Sort By</h3>
             <div className="relative">
                <button
                    onClick={() => toggleFilterDropdown('sort')}
                    className="w-full flex justify-between items-center px-3 py-2 border border-gray-300 rounded-md bg-white text-sm text-gray-700 hover:bg-gray-50"
                >
                    {currentSort === 'rating' ? 'Highest Rated' : currentSort === 'price-asc' ? 'Price: Low to High' : currentSort === 'price-desc' ? 'Price: High to Low' : 'Relevance'}
                    <IconChevronDown className={`w-4 h-4 transition-transform ${filterDropdownOpen === 'sort' ? 'rotate-180' : ''}`} />
                </button>
                {filterDropdownOpen === 'sort' && (
                    <div className="absolute left-0 right-0 mt-1 w-full bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
                        {['relevance', 'rating', 'price-asc', 'price-desc'].map(option => (
                            <button
                                key={option}
                                onClick={() => handleSortChange(option)}
                                className={`block w-full text-left px-4 py-2 text-sm ${currentSort === option ? 'bg-primary-light text-primary' : 'text-gray-700 hover:bg-gray-100'}`}
                            >
                                {option === 'rating' ? 'Highest Rated' : option === 'price-asc' ? 'Price: Low to High' : option === 'price-desc' ? 'Price: High to Low' : 'Relevance'}
                            </button>
                        ))}
                    </div>
                )}
            </div>
          </div>
        </aside>

        {/* Course Grid */}
        <main className="w-full md:w-3/4 lg:w-4/5">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Spinner size="lg" />
            </div>
          ) : courses.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map(course => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h2 className="text-2xl font-semibold text-gray-700 mb-2">No Courses Found</h2>
              <p className="text-gray-500 mb-6">Try adjusting your search or filters, or explore all our courses.</p>
              <Link to="/courses" className="text-primary hover:underline">View All Courses</Link>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default CourseListPage;
