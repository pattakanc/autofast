
import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import type { Course, Category } from '../types';
import { getFeaturedCourses, getCategories } from '../services/courseService';
import CourseCard from '../components/ui/CourseCard';
import Spinner from '../components/ui/Spinner';
import Button from '../components/ui/Button';
import SearchBar from '../components/ui/SearchBar';
import { APP_NAME, IconChevronLeftSolid, IconChevronRightSolid } from '../constants';

interface HeroBannerData {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  ctaText: string;
  ctaLink: string;
  searchPlaceholder: string;
}

const heroBanners: HeroBannerData[] = [
  {
    id: 'banner1',
    title: 'Discover Your Next Passion',
    subtitle: 'Explore thousands of courses taught by industry experts. Start learning today!',
    imageUrl: 'https://picsum.photos/seed/homepagebanner1/1200/600',
    ctaText: 'Explore All Courses',
    ctaLink: '/courses',
    searchPlaceholder: 'What skill will you learn today?',
  },
  {
    id: 'banner2',
    title: 'New! AI & Machine Learning Bootcamp',
    subtitle: 'Dive into the world of Artificial Intelligence. No prior experience needed for our beginner tracks.',
    imageUrl: 'https://picsum.photos/seed/homepagebanner2/1200/600',
    ctaText: 'View AI Courses',
    ctaLink: '/courses?category=data-science',
    searchPlaceholder: 'Search for AI or ML courses...',
  },
  {
    id: 'banner3',
    title: 'Summer Sale: Up to 50% Off!',
    subtitle: 'Don\'t miss out on our biggest sale of the year. Limited time offer on select courses.',
    imageUrl: 'https://picsum.photos/seed/homepagebanner3/1200/600',
    ctaText: 'Find Your Course',
    ctaLink: '/courses?sort=price-asc',
    searchPlaceholder: 'Find courses on sale...',
  },
];

const HomePage: React.FC = () => {
  const [featuredCourses, setFeaturedCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const navigate = useNavigate();

  const handleNextBanner = useCallback(() => {
    setCurrentBannerIndex((prevIndex) => (prevIndex + 1) % heroBanners.length);
  }, []);

  const handlePrevBanner = () => {
    setCurrentBannerIndex((prevIndex) => (prevIndex - 1 + heroBanners.length) % heroBanners.length);
  };

  const goToBanner = (index: number) => {
    setCurrentBannerIndex(index);
  };
  
  useEffect(() => {
    const timer = setTimeout(() => {
      handleNextBanner();
    }, 7000); // Change banner every 7 seconds
    return () => clearTimeout(timer); // Cleanup timer
  }, [currentBannerIndex, handleNextBanner]);


  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [coursesData, categoriesData] = await Promise.all([
          getFeaturedCourses(),
          getCategories()
        ]);
        setFeaturedCourses(coursesData);
        setCategories(categoriesData);
      } catch (error) {
        console.error("Error fetching homepage data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSearch = (query: string) => {
    navigate(`/courses?search=${encodeURIComponent(query)}`);
  };

  if (loading && featuredCourses.length === 0) { // Keep showing content if only banners are loading
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
        <Spinner size="lg" />
      </div>
    );
  }

  const currentBanner = heroBanners[currentBannerIndex];

  return (
    <div className="space-y-12">
      {/* Hero Section Banner Carousel */}
      <section 
        className="relative bg-cover bg-center py-20 px-4 rounded-lg shadow-xl text-white overflow-hidden"
        style={{ backgroundImage: `url('${currentBanner.imageUrl}')` }}
        aria-labelledby={`hero-heading-${currentBanner.id}`}
        aria-roledescription="carousel"
        aria-live="polite"
      >
        <div className="absolute inset-0 bg-black opacity-60 rounded-lg"></div>
        
        <div className="container mx-auto text-center relative z-10 min-h-[300px] md:min-h-[350px] flex flex-col justify-center">
          <h1 id={`hero-heading-${currentBanner.id}`} className="text-4xl md:text-5xl font-bold mb-4">{currentBanner.title}</h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">
            {currentBanner.subtitle}
          </p>
          <div className="max-w-xl mx-auto mb-8">
            <SearchBar 
              onSearch={handleSearch} 
              placeholder={currentBanner.searchPlaceholder}
              className="bg-white rounded-full shadow-lg"
            />
          </div>
          <Button size="lg" variant="primary" onClick={() => navigate(currentBanner.ctaLink)}>
            {currentBanner.ctaText}
          </Button>
        </div>

        {/* Carousel Navigation Buttons */}
        <button
          onClick={handlePrevBanner}
          className="absolute top-1/2 left-2 md:left-4 transform -translate-y-1/2 bg-black bg-opacity-30 hover:bg-opacity-50 text-white p-2 rounded-full z-20 transition-opacity"
          aria-label="Previous banner"
        >
          <IconChevronLeftSolid className="w-6 h-6 md:w-8 md:h-8" />
        </button>
        <button
          onClick={handleNextBanner}
          className="absolute top-1/2 right-2 md:right-4 transform -translate-y-1/2 bg-black bg-opacity-30 hover:bg-opacity-50 text-white p-2 rounded-full z-20 transition-opacity"
          aria-label="Next banner"
        >
          <IconChevronRightSolid className="w-6 h-6 md:w-8 md:h-8" />
        </button>

        {/* Dot Indicators */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
          {heroBanners.map((_, index) => (
            <button
              key={`dot-${index}`}
              onClick={() => goToBanner(index)}
              aria-label={`Go to banner ${index + 1}`}
              className={`w-3 h-3 rounded-full transition-colors ${
                currentBannerIndex === index ? 'bg-white' : 'bg-gray-400 hover:bg-gray-200'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Featured Courses Section */}
      <section>
        <h2 className="text-3xl font-semibold mb-6 text-gray-800">Featured Courses</h2>
        {loading && featuredCourses.length === 0 ? (
           <div className="flex justify-center items-center py-10"><Spinner size="md" /></div>
        ) : featuredCourses.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        ) : (
          <p>No featured courses available at the moment.</p>
        )}
      </section>

      {/* Categories Section */}
      <section>
        <h2 className="text-3xl font-semibold mb-6 text-gray-800">Top Categories</h2>
         {loading && categories.length === 0 ? (
           <div className="flex justify-center items-center py-10"><Spinner size="md" /></div>
        ) : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories.map(category => (
            <Link
              key={category.id}
              to={`/courses?category=${category.slug}`}
              className="block p-6 bg-white rounded-lg shadow hover:shadow-lg transition-shadow text-center hover:bg-primary-light"
            >
              <span className="text-lg font-medium text-gray-700 hover:text-primary">{category.name}</span>
            </Link>
          ))}
        </div>}
      </section>

      {/* Call to Action Section */}
      <section className="bg-primary-light p-12 rounded-lg text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-4">Ready to Start Learning?</h2>
        <p className="text-gray-600 mb-8 max-w-xl mx-auto">
          Join thousands of learners who are achieving their goals with {APP_NAME}. Find the perfect course for you.
        </p>
        <Button size="lg" onClick={() => navigate('/courses')}>Browse Courses</Button>
      </section>
    </div>
  );
};

export default HomePage;
