
import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import type { Course, CurriculumSection, Lesson, Review } from '../types';
import { getCourseById, getCoursesByInstructor } from '../services/courseService';
import Spinner from '../components/ui/Spinner';
import StarRating from '../components/ui/StarRating';
import Button from '../components/ui/Button';
import LessonItem from '../components/ui/LessonItem';
import CourseCard from '../components/ui/CourseCard';
import { 
  IconStar, IconPlayCircle, IconChevronDown, IconChevronUp, IconBookOpen, 
  IconCheckCircle, IconClock, IconUsers, IconCalendarDays, IconAcademicCap,
  IconUserCircle
} from '../constants';
import { useCart } from '../contexts/CartContext'; 
import { useCurrency } from '../contexts/CurrencyContext'; // Import useCurrency

// Helper function to find the first previewable lesson in a course
const findFirstPreviewableLessonInCourse = (course: Course): Lesson | undefined => {
  if (!course.curriculum) return undefined;
  for (const section of course.curriculum) {
    const previewable = section.lessons.find(l => l.previewable);
    if (previewable) return previewable;
  }
  return undefined;
};

const CourseDetailPage: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const navigate = useNavigate();
  const [course, setCourse] = useState<Course | null>(null);
  const [relatedCourses, setRelatedCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'curriculum' | 'instructor' | 'reviews'>('overview');
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  
  const { formatPrice } = useCurrency(); // Use currency context

  useEffect(() => {
    const fetchCourse = async () => {
      if (!courseId) {
        setError("Course ID is missing.");
        setLoading(false);
        return;
      }
      try {
        setLoading(true);
        setError(null);
        const courseData = await getCourseById(courseId);
        if (courseData) {
          setCourse(courseData);
          const initialExpanded: Record<string, boolean> = {};
          if (courseData.curriculum && courseData.curriculum.length > 0) {
            initialExpanded[courseData.curriculum[0].id] = true; 
          }
          setExpandedSections(initialExpanded);

          const instructorCourses = await getCoursesByInstructor(courseData.instructor.id);
          setRelatedCourses(instructorCourses.filter(c => c.id !== courseData.id).slice(0,3));

        } else {
          setError("Course not found.");
        }
      } catch (err) {
        console.error("Error fetching course:", err);
        setError("Failed to load course details.");
      } finally {
        setLoading(false);
      }
    };
    fetchCourse();
  }, [courseId]);

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const handleLessonPreview = (lessonToPreview: Lesson) => {
    if (course && lessonToPreview.previewable) {
      navigate(`/courses/${course.id}/lessons/${lessonToPreview.id}/preview`);
    } else {
      alert("This lesson is not available for preview.");
    }
  };

  const handleRatingClick = () => {
    setActiveTab('reviews');
    setTimeout(() => {
        const reviewsSection = document.getElementById('reviews-section-content');
        if (reviewsSection) {
            reviewsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 0);
  };

  const handleInstructorNameClick = () => {
    setActiveTab('instructor');
    setTimeout(() => {
      const instructorSection = document.getElementById('instructor-section-content');
      if (instructorSection) {
        instructorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 0);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
        <Spinner size="lg" />
      </div>
    );
  }

  if (error) {
    return <div className="text-center text-red-500 text-xl py-10">{error}</div>;
  }

  if (!course) {
    return <div className="text-center text-xl py-10">Course data is unavailable.</div>;
  }
  
  const totalLessons = course.curriculum?.reduce((acc, section) => acc + section.lessons.length, 0) || 0;

  return (
    <div className="course-detail-page">
      <header className="bg-gray-800 text-white py-12 md:py-16 px-4">
        <div className="container mx-auto md:flex md:items-start md:space-x-8">
          <div className="md:w-2/3">
            <nav aria-label="breadcrumb" className="text-sm text-gray-300 mb-2">
              <Link to="/courses" className="hover:underline">Courses</Link> &gt; 
              <Link to={`/courses?category=${course.category.toLowerCase().replace(/\s+/g, '-')}`} className="hover:underline">{course.category}</Link>
            </nav>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{course.title}</h1>
            {course.subtitle && <p className="text-lg md:text-xl text-gray-300 mb-4">{course.subtitle}</p>}
            <div className="flex items-center space-x-4 mb-4 text-sm">
              <button
                onClick={handleRatingClick}
                className="flex items-center text-left hover:opacity-75 transition-opacity focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:ring-offset-2 focus:ring-offset-gray-800 rounded-sm p-0.5 -ml-0.5"
                aria-label={`View ${course.reviewsCount.toLocaleString()} reviews and rating details for ${course.title}`}
              >
                <span className="font-semibold text-yellow-400 mr-1">{course.rating.toFixed(1)}</span>
                <StarRating rating={course.rating} starSize="w-5 h-5" />
                <span className="ml-2 text-gray-300">({course.reviewsCount.toLocaleString()} ratings)</span>
              </button>
              <span className="text-gray-300">{course.studentsEnrolled.toLocaleString()} students</span>
            </div>
            <div className="text-sm text-gray-300">
              Created by{' '}
              <button
                onClick={handleInstructorNameClick}
                className="font-semibold text-accent hover:underline focus:outline-none focus:ring-2 focus:ring-accent focus:ring-offset-2 focus:ring-offset-gray-800 rounded-sm"
                aria-label={`View details for instructor ${course.instructor.name}`}
              >
                {course.instructor.name}
              </button>
            </div>
            <div className="flex space-x-4 mt-2 text-sm text-gray-300">
              <span><IconCalendarDays className="inline w-4 h-4 mr-1" /> Last updated {new Date(course.lastUpdated).toLocaleDateString()}</span>
              <span><IconBookOpen className="inline w-4 h-4 mr-1" /> {course.language}</span>
            </div>
          </div>
          <div className="hidden md:block md:w-1/3 sticky top-24 self-start">
             <CourseBuyCard course={course} formatPrice={formatPrice} />
          </div>
        </div>
      </header>

      <div className="container mx-auto py-8 px-4 md:flex md:space-x-8">
        <div className="md:w-2/3">
          {course.whatYouWillLearn && course.whatYouWillLearn.length > 0 && (
            <section className="mb-8 p-6 border border-gray-200 rounded-lg bg-white">
              <h2 className="text-2xl font-semibold mb-4">What you'll learn</h2>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                {course.whatYouWillLearn.map((item, index) => (
                  <li key={index} className="flex items-start">
                    <IconCheckCircle className="w-5 h-5 text-green-500 mr-3 mt-1 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          <div className="mb-8 border-b border-gray-200">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
              {['overview', 'curriculum', 'instructor', 'reviews'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm capitalize
                    ${activeTab === tab
                      ? 'border-primary text-primary'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  aria-controls={`${tab}-section-content`}
                  role="tab"
                  aria-selected={activeTab === tab}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div>
            {activeTab === 'overview' && (
              <div id="overview-section-content" role="tabpanel" aria-labelledby="overview-tab-button" className="space-y-6 prose max-w-none">
                <h3 className="text-xl font-semibold">Course Description</h3>
                <p>{course.longDescription || course.description}</p>
                {course.requirements && course.requirements.length > 0 && (
                  <>
                    <h3 className="text-xl font-semibold">Requirements</h3>
                    <ul className="list-disc pl-5 space-y-1">
                      {course.requirements.map((req, i) => <li key={i}>{req}</li>)}
                    </ul>
                  </>
                )}
              </div>
            )}

            {activeTab === 'curriculum' && (
              <div id="curriculum-section-content" role="tabpanel" aria-labelledby="curriculum-tab-button" className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-semibold">Course Content</h2>
                    <span className="text-sm text-gray-600">{course.curriculum?.length || 0} sections &bull; {totalLessons} lectures &bull; {course.duration} total length</span>
                </div>
                {course.curriculum && course.curriculum.length > 0 ? (
                  course.curriculum.map((section) => (
                    <div key={section.id} className="border border-gray-200 rounded-md bg-white">
                      <button
                        onClick={() => toggleSection(section.id)}
                        className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 rounded-t-md"
                        aria-expanded={expandedSections[section.id]}
                        aria-controls={`section-content-${section.id}`}
                      >
                        <span className="font-semibold text-gray-800">{section.title}</span>
                        <div className="flex items-center space-x-2">
                           <span className="text-sm text-gray-600">{section.lessons.length} lectures</span>
                          {expandedSections[section.id] ? <IconChevronUp /> : <IconChevronDown />}
                        </div>
                      </button>
                      {expandedSections[section.id] && (
                        <div id={`section-content-${section.id}`} className="p-2 divide-y divide-gray-100">
                          {section.lessons.map((lesson) => (
                            <LessonItem key={lesson.id} lesson={lesson} onPreview={handleLessonPreview} />
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p>No curriculum available for this course.</p>
                )}
              </div>
            )}

            {activeTab === 'instructor' && (
              <div id="instructor-section-content" role="tabpanel" aria-labelledby="instructor-tab-button" className="bg-white p-6 rounded-lg border border-gray-200">
                <h2 className="text-2xl font-semibold mb-4">About the Instructor</h2>
                <div className="flex items-start space-x-4">
                  <img 
                    src={`${course.instructor.avatarUrl}?seed=${course.instructor.id}`} 
                    alt={course.instructor.name} 
                    className="w-24 h-24 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="text-xl font-bold text-primary">{course.instructor.name}</h3>
                    {course.instructor.rating && (
                      <div className="flex items-center text-sm text-gray-600 my-1">
                        <IconStar className="w-4 h-4 text-yellow-400 mr-1" />
                        <span>{course.instructor.rating} Instructor Rating</span>
                      </div>
                    )}
                     {course.instructor.reviews && (
                       <div className="flex items-center text-sm text-gray-600 my-1">
                        <IconUsers className="w-4 h-4 text-gray-500 mr-1" />
                        <span>{course.instructor.reviews.toLocaleString()} Reviews</span>
                      </div>
                     )}
                    {course.instructor.coursesCount && (
                       <div className="flex items-center text-sm text-gray-600 my-1">
                        <IconAcademicCap className="w-4 h-4 text-gray-500 mr-1" />
                        <span>{course.instructor.coursesCount.toLocaleString()} Courses</span>
                      </div>
                    )}
                  </div>
                </div>
                <p className="mt-4 text-gray-700 prose max-w-none">{course.instructor.bio}</p>
                {relatedCourses.length > 0 && (
                  <div className="mt-8">
                    <h3 className="text-xl font-semibold mb-4">More Courses by {course.instructor.name}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {relatedCourses.map(rc => <CourseCard key={rc.id} course={rc} />)}
                    </div>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'reviews' && (
              <div id="reviews-section-content" role="tabpanel" aria-labelledby="reviews-tab-button" className="bg-white p-6 rounded-lg border border-gray-200">
                <h2 className="text-2xl font-semibold mb-6">Student Feedback</h2>
                
                <div className="flex items-center mb-6 space-x-3">
                  <div className="text-5xl font-bold text-yellow-500">{course.rating.toFixed(1)}</div>
                  <div>
                    <StarRating rating={course.rating} starSize="w-6 h-6" />
                    <p className="text-sm text-gray-600 mt-1">Course Rating ({course.reviewsCount.toLocaleString()} reviews)</p>
                  </div>
                </div>

                {course.reviews && course.reviews.length > 0 ? (
                  <div className="space-y-6">
                    {course.reviews.map((review: Review) => (
                      <div key={review.id} className="pb-6 border-b border-gray-200 last:border-b-0">
                        <div className="flex items-start space-x-3">
                          {review.reviewerAvatarUrl ? (
                            <img src={review.reviewerAvatarUrl} alt={review.reviewerName} className="w-10 h-10 rounded-full object-cover" />
                          ) : (
                            <IconUserCircle className="w-10 h-10 text-gray-400" />
                          )}
                          <div>
                            <h4 className="text-md font-semibold text-gray-800">{review.reviewerName}</h4>
                            <div className="flex items-center space-x-2 mt-1">
                              <StarRating rating={review.rating} starSize="w-4 h-4" />
                              <span className="text-xs text-gray-500">{new Date(review.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                            </div>
                          </div>
                        </div>
                        <p className="mt-3 text-gray-700 text-sm leading-relaxed whitespace-pre-line">{review.comment}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p>No reviews yet for this course.</p>
                    <p>Be the first one to share your thoughts!</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        
        <div className="md:hidden mt-8">
          <CourseBuyCard course={course} formatPrice={formatPrice} />
        </div>
      </div>
    </div>
  );
};


interface CourseBuyCardProps {
  course: Course;
  formatPrice: (priceInUsd: number, options?: { includeSymbol?: boolean }) => string; // Pass formatPrice
}

const CourseBuyCard: React.FC<CourseBuyCardProps> = ({ course, formatPrice }) => {
  const { addToCart, isCourseInCart } = useCart();
  const navigate = useNavigate();
  const isInCart = isCourseInCart(course.id);

  const firstPreviewableLesson = useMemo(() => findFirstPreviewableLessonInCourse(course), [course]);

  const handleAddToCart = () => {
    if (isInCart) {
      navigate('/cart');
    } else {
      addToCart(course);
    }
  };

  const handleBuyNow = () => {
    if (!isInCart) {
      addToCart(course);
    }
    navigate('/cart');
  };

  const handleCoursePreviewClick = () => {
    if (firstPreviewableLesson) {
      navigate(`/courses/${course.id}/lessons/${firstPreviewableLesson.id}/preview`);
    }
  };
  
  const totalLessons = course.curriculum?.reduce((acc, section) => acc + section.lessons.length, 0) || 0;
  
  return (
    <div className="bg-white shadow-xl rounded-lg overflow-hidden border border-gray-200">
      <div className="relative">
        <img src={`${course.thumbnailUrl}?seed=${course.id}-preview`} alt={`${course.title} preview`} className="w-full h-48 object-cover" />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <button 
            onClick={handleCoursePreviewClick}
            disabled={!firstPreviewableLesson}
            className="text-white hover:text-opacity-80 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label={firstPreviewableLesson ? "Preview this course" : "No preview available for this course"}
          >
            <IconPlayCircle className="w-16 h-16" />
            <span className="block mt-1 text-sm font-semibold">
              {firstPreviewableLesson ? "Preview this course" : "Preview N/A"}
            </span>
          </button>
        </div>
      </div>
      <div className="p-6 space-y-4">
        <div className="flex items-baseline space-x-2">
          <span className="text-3xl font-bold text-gray-800">{formatPrice(course.price)}</span>
          {course.originalPrice && (
            <span className="text-lg text-gray-500 line-through">{formatPrice(course.originalPrice)}</span>
          )}
        </div>
        {course.originalPrice && (
            <p className="text-sm text-red-600 font-semibold">
                {Math.round(((course.originalPrice - course.price) / course.originalPrice) * 100)}% off
            </p>
        )}
        <Button 
          variant={isInCart ? "outline" : "secondary"} 
          size="lg" 
          fullWidth 
          onClick={handleAddToCart}
        >
          {isInCart ? "Go to Cart" : "Add to Cart"}
        </Button>
        <Button variant="primary" size="lg" fullWidth onClick={handleBuyNow}>
          Buy Now
        </Button>
        <p className="text-xs text-gray-500 text-center">30-Day Money-Back Guarantee</p>
        
        <div className="pt-4 border-t border-gray-200">
          <h4 className="font-semibold text-gray-700 mb-2">This course includes:</h4>
          <ul className="space-y-1.5 text-sm text-gray-600">
            <li className="flex items-center"><IconClock className="w-4 h-4 mr-2 text-gray-500" />{course.duration} on-demand video</li>
            <li className="flex items-center"><IconBookOpen className="w-4 h-4 mr-2 text-gray-500" />{totalLessons > 0 ? `${totalLessons} articles/lessons` : 'Multiple articles & resources'}</li>
            <li className="flex items-center"><IconAcademicCap className="w-4 h-4 mr-2 text-gray-500" />Certificate of completion</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default CourseDetailPage;
