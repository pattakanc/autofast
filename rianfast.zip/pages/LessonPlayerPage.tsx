
import React, { useEffect, useState, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { getCourseById } from '../services/courseService';
import type { Course, Lesson } from '../types';
import Spinner from '../components/ui/Spinner';
import Button from '../components/ui/Button';
import { IconPlayCircle, IconArrowLeft, IconBookOpen, IconVideoCamera } from '../constants';

const DEFAULT_VIDEO_URL = 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm';

const LessonPlayerPage: React.FC = () => {
  const { courseId, lessonId } = useParams<{ courseId: string; lessonId: string }>();
  const navigate = useNavigate();
  const [course, setCourse] = useState<Course | null>(null);
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLessonData = async () => {
      if (!courseId || !lessonId) {
        setError("Course ID or Lesson ID is missing.");
        setLoading(false);
        return;
      }
      try {
        setLoading(true);
        setError(null);
        const courseData = await getCourseById(courseId);
        if (!courseData) {
          setError("Course not found. Please check the URL or go back.");
          setLoading(false);
          return;
        }
        setCourse(courseData);

        let foundLesson: Lesson | undefined;
        for (const section of courseData.curriculum || []) {
          foundLesson = section.lessons.find(l => l.id === lessonId);
          if (foundLesson) break;
        }

        if (!foundLesson) {
          setError("Lesson not found in this course. It might have been moved or an incorrect link was followed.");
          setLoading(false);
          return;
        }
        if (!foundLesson.previewable) {
          setError("This lesson is not available for preview. Please enroll in the course to view it.");
          setLoading(false);
          return;
        }
        setLesson(foundLesson);
      } catch (err) {
        console.error("Error fetching lesson data:", err);
        setError("Failed to load lesson details. An unexpected error occurred.");
      } finally {
        setLoading(false);
      }
    };
    fetchLessonData();
  }, [courseId, lessonId]);

  const LessonIcon = useMemo(() => {
    if (!lesson) return IconBookOpen;
    return lesson.type === 'video' ? IconVideoCamera : IconBookOpen;
  }, [lesson]);

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gray-100 p-4">
        <Spinner size="lg" />
        <p className="mt-4 text-gray-600">Loading lesson...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gray-100 p-4 text-center">
        <h2 className="text-2xl font-semibold text-red-600 mb-4">Error</h2>
        <p className="text-gray-700 mb-6">{error}</p>
        <Button onClick={() => navigate(courseId ? `/courses/${courseId}` : '/courses')} variant="primary">
          {courseId ? 'Back to Course' : 'Explore Courses'}
        </Button>
      </div>
    );
  }

  if (!course || !lesson) {
     return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gray-100 p-4 text-center">
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Lesson Unavailable</h2>
        <p className="text-gray-600 mb-6">The requested lesson data could not be found.</p>
        <Button onClick={() => navigate(courseId ? `/courses/${courseId}` : '/courses')} variant="primary">
          {courseId ? 'Back to Course' : 'Explore Courses'}
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-800 text-white flex flex-col">
      <header className="p-4 bg-gray-900 shadow-lg sticky top-0 z-50">
        <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center">
          <div className="mb-2 sm:mb-0">
            <Link to={`/courses/${course.id}`} className="text-sm text-gray-400 hover:text-accent flex items-center">
              <IconArrowLeft className="w-4 h-4 mr-2" />
              Back to {course.title}
            </Link>
            <h1 className="text-xl md:text-2xl font-semibold mt-1 flex items-center">
              <LessonIcon className="w-6 h-6 mr-2 text-accent" />
              {lesson.title}
            </h1>
          </div>
          <span className="text-xs text-gray-500">Preview Mode</span>
        </div>
      </header>

      <main className="flex-grow container mx-auto p-4 md:p-8 flex flex-col items-center justify-center">
        <div className="w-full max-w-4xl bg-black rounded-lg shadow-2xl overflow-hidden" style={{aspectRatio: '16 / 9'}}>
          {lesson.type === 'video' && (
            <video
              src={lesson.contentUrl || DEFAULT_VIDEO_URL}
              controls
              className="w-full h-full object-contain" // Use object-contain to prevent cropping
              aria-label={`Video preview for ${lesson.title}`}
            >
              Your browser does not support the video tag.
              {lesson.contentUrl ? ` You can download the video from ${lesson.contentUrl}` : ''}
            </video>
          )}
          {lesson.type === 'article' && (
             <div className="p-6 md:p-8 overflow-y-auto h-full w-full bg-gray-700 text-gray-200">
                <h2 className="text-xl md:text-2xl font-bold mb-4 text-white">{lesson.title}</h2>
                {lesson.contentText ? (
                  <div 
                    className="prose-like text-sm md:text-base" 
                    dangerouslySetInnerHTML={{ __html: lesson.contentText.replace(/\n/g, '<br />') }} 
                  />
                ) : (
                  <p>Article content would be displayed here.</p>
                )}
                 <p className="text-xs mt-4 text-gray-400">This is a demo. Rich text formatting might be limited.</p>
             </div>
          )}
           {lesson.type === 'quiz' && (
            <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 text-center p-4">
                <IconBookOpen className="w-16 h-16 md:w-24 md:h-24 text-gray-500 opacity-60" />
                <p className="mt-2 md:mt-4 text-sm md:text-lg">Quiz content for "{lesson.title}" would be presented here.</p>
                 <p className="text-xs mt-2 text-gray-600">This is a demo. Interactive quiz functionality is not implemented.</p>
            </div>
        )}
        </div>
        <div className="mt-6">
            <Button variant="outline" onClick={() => navigate(`/courses/${course.id}`)} className="bg-opacity-20 border-gray-500 hover:bg-gray-700">
                Finish Preview & Back to Course
            </Button>
        </div>
      </main>
      
      <footer className="p-3 bg-gray-900 text-center text-xs text-gray-600">
        You are previewing: "{lesson.title}" from the course "{course.title}".
      </footer>
       <style>{`
        .prose-like p { margin-bottom: 1em; line-height: 1.6;}
        .prose-like h1, .prose-like h2, .prose-like h3 { font-weight: bold; margin-top: 1.5em; margin-bottom: 0.5em; color: white;}
        .prose-like ul, .prose-like ol { margin-left: 1.5em; margin-bottom: 1em; }
        .prose-like li { margin-bottom: 0.25em; }
        .prose-like a { color: var(--color-accent, #F59E0B); text-decoration: underline;}
      `}</style>
    </div>
  );
};

export default LessonPlayerPage;
