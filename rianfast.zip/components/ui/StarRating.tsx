
import React from 'react';
import { IconStar } from '../../constants';

interface StarRatingProps {
  rating: number;
  maxStars?: number;
  starSize?: string; // e.g., "w-5 h-5"
}

const StarRating: React.FC<StarRatingProps> = ({ rating, maxStars = 5, starSize = "w-4 h-4" }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5; // Not implemented visually, showing full or empty for simplicity
  const emptyStars = maxStars - fullStars - (halfStar ? 1 : 0); // Adjust if half star is visually distinct

  return (
    <div className="flex items-center">
      {[...Array(fullStars)].map((_, i) => (
        <IconStar key={`full-${i}`} className={`${starSize} text-yellow-400`} filled />
      ))}
      {/* Placeholder for half star if needed */}
      {/* {halfStar && <IconStarHalf key="half" className={`${starSize} text-yellow-400`} />} */}
      {[...Array(Math.max(0, maxStars - fullStars))].map((_, i) => (
        <IconStar key={`empty-${i}`} className={`${starSize} text-gray-300`} filled={false} />
      ))}
    </div>
  );
};

export default StarRating;
