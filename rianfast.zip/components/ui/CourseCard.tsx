
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import type { Course } from '../../types';
import StarRating from './StarRating';
import Button from './Button';
import { IconUsers } from '../../constants';
import { useCart } from '../../contexts/CartContext';
import { useCurrency } from '../../contexts/CurrencyContext'; // Import useCurrency

interface CourseCardProps {
  course: Course;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  const { addToCart, isCourseInCart } = useCart();
  const { formatPrice } = useCurrency(); // Use currency context
  const navigate = useNavigate();
  const isInCart = isCourseInCart(course.id);

  const handleCartAction = () => {
    if (isInCart) {
      navigate('/cart');
    } else {
      addToCart(course);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
      <Link to={`/courses/${course.id}`} className="block">
        <img 
          src={`${course.thumbnailUrl}?seed=${course.id}`} 
          alt={course.title} 
          className="w-full h-48 object-cover" 
        />
      </Link>
      <div className="p-4 flex flex-col flex-grow">
        <Link to={`/courses/${course.id}`} className="block">
          <h3 className="text-lg font-semibold text-gray-800 hover:text-primary transition-colors min-h-[3em] line-clamp-2">{course.title}</h3>
        </Link>
        <p className="text-sm text-gray-500 mt-1">{course.instructor.name}</p>
        <div className="flex items-center my-2">
          <span className="text-yellow-500 font-bold mr-1">{course.rating.toFixed(1)}</span>
          <StarRating rating={course.rating} />
          <span className="text-xs text-gray-500 ml-2">({course.reviewsCount.toLocaleString()})</span>
        </div>
        <div className="flex items-center text-sm text-gray-500 mb-2">
          <IconUsers className="w-4 h-4 mr-1 text-gray-400" />
          <span>{course.studentsEnrolled.toLocaleString()} students</span>
        </div>
        <div className="mt-auto">
           <div className="flex justify-between items-center mb-3">
            <p className="text-xl font-bold text-primary">
              {formatPrice(course.price)}
            </p>
            {course.originalPrice && (
              <p className="text-sm text-gray-500 line-through">
                {formatPrice(course.originalPrice)}
              </p>
            )}
          </div>
          <Button 
            variant={isInCart ? "outline" : "primary"}
            fullWidth 
            onClick={handleCartAction}
            className="text-sm py-2"
          >
            {isInCart ? "Go to Cart" : "Add to Cart"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
