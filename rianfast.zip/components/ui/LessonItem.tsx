
import React from 'react';
import type { Lesson } from '../../types';
import { IconBookOpen, IconVideoCamera, IconPlayCircle } from '../../constants';

interface LessonItemProps {
  lesson: Lesson;
  onPreview?: (lesson: Lesson) => void;
}

const LessonItem: React.FC<LessonItemProps> = ({ lesson, onPreview }) => {
  const Icon = lesson.type === 'video' ? IconVideoCamera : IconBookOpen;

  return (
    <div className="flex justify-between items-center py-3 px-2 hover:bg-gray-50 rounded-md">
      <div className="flex items-center space-x-3">
        <Icon className="w-5 h-5 text-gray-500" />
        <span className="text-sm text-gray-700">{lesson.title}</span>
      </div>
      <div className="flex items-center space-x-3">
        {lesson.previewable && onPreview && (
          <button 
            onClick={() => onPreview(lesson)} 
            className="text-xs text-primary hover:underline flex items-center"
          >
            <IconPlayCircle className="w-4 h-4 mr-1" /> Preview
          </button>
        )}
        <span className="text-xs text-gray-500">{lesson.duration}</span>
      </div>
    </div>
  );
};

export default LessonItem;
