
import React from 'react';
import { Link } from 'react-router-dom';
import { APP_NAME, categoriesList } from '../../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-gray-300 pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h5 className="text-lg font-semibold text-white mb-4">{APP_NAME}</h5>
            <p className="text-sm">Empowering learners worldwide through accessible and quality education.</p>
          </div>
          <div>
            <h5 className="text-lg font-semibold text-white mb-4">Quick Links</h5>
            <ul className="space-y-2">
              <li><Link to="/courses" className="hover:text-white">All Courses</Link></li>
              <li><Link to="/my-learning" className="hover:text-white">My Learning</Link></li>
              <li><a href="#" className="hover:text-white">Become an Instructor</a></li>
              <li><a href="#" className="hover:text-white">About Us</a></li>
            </ul>
          </div>
          <div>
            <h5 className="text-lg font-semibold text-white mb-4">Categories</h5>
            <ul className="space-y-2">
              {categoriesList.slice(0, 5).map(cat => (
                <li key={cat.id}><Link to={`/courses?category=${cat.slug}`} className="hover:text-white">{cat.name}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-lg font-semibold text-white mb-4">Support</h5>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">Help Center</a></li>
              <li><a href="#" className="hover:text-white">Contact Us</a></li>
              <li><a href="#" className="hover:text-white">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-700 pt-8 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
