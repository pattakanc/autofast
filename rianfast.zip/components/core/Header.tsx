
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  APP_NAME, 
  IconChevronDown, 
  IconSearch, 
  IconShoppingCart, 
  IconUserCircle, 
  IconMenu, 
  IconX, 
  IconGlobeAlt,
  categoriesList 
} from '../../constants';
import SearchBar from '../ui/SearchBar';
import { useCart } from '../../contexts/CartContext';
import { useCurrency } from '../../contexts/CurrencyContext'; // Import useCurrency

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCategoriesDropdownOpen, setIsCategoriesDropdownOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isCurrencyDropdownOpen, setIsCurrencyDropdownOpen] = useState(false); // State for currency dropdown
  
  const categoriesDropdownRef = useRef<HTMLDivElement>(null);
  const profileDropdownRef = useRef<HTMLDivElement>(null);
  const currencyDropdownRef = useRef<HTMLDivElement>(null); // Ref for currency dropdown
  
  const { getCartItemCount } = useCart();
  const { currentCurrency, setCurrency, supportedCurrencies } = useCurrency(); // Currency context
  const navigate = useNavigate();

  const cartItemCount = getCartItemCount();

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const toggleCategoriesDropdown = () => setIsCategoriesDropdownOpen(!isCategoriesDropdownOpen);
  const toggleProfileDropdown = () => setIsProfileDropdownOpen(!isProfileDropdownOpen);
  const toggleCurrencyDropdown = () => setIsCurrencyDropdownOpen(!isCurrencyDropdownOpen); // Toggle for currency

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (categoriesDropdownRef.current && !categoriesDropdownRef.current.contains(event.target as Node)) {
        setIsCategoriesDropdownOpen(false);
      }
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(event.target as Node)) {
        setIsProfileDropdownOpen(false);
      }
      if (currencyDropdownRef.current && !currencyDropdownRef.current.contains(event.target as Node)) { // Handle currency dropdown
        setIsCurrencyDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = (query: string) => {
    navigate(`/courses?search=${encodeURIComponent(query)}`);
  };

  const handleSignOut = () => {
    localStorage.removeItem('rianfastCart');
    setIsProfileDropdownOpen(false);
    navigate('/');
  };

  const ProfileDropdownItem: React.FC<{ to?: string; onClick?: () => void; children: React.ReactNode; hasBadge?: boolean; isButton?: boolean}> = 
    ({ to, onClick, children, hasBadge, isButton }) => {
    const commonProps = {
      className: "w-full text-left block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex justify-between items-center",
      onClick: () => {
        if(onClick) onClick();
        setIsProfileDropdownOpen(false);
      }
    };
    const content = (
      <>
        <span>{children}</span>
        {hasBadge && (
          <span className="ml-auto bg-purple-600 text-white text-xs font-semibold px-2 py-0.5 rounded-full">9+</span>
        )}
      </>
    );

    if (isButton) {
        return <button {...commonProps}>{content}</button>;
    }

    return (
      <Link to={to || '/'} {...commonProps}>
        {content}
      </Link>
    );
  };


  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo and Main Nav */}
          <div className="flex items-center space-x-8">
            <Link to="/" className="text-2xl font-bold text-primary">
              {APP_NAME}
            </Link>
            <nav className="hidden md:flex items-center space-x-4">
              <div className="relative" ref={categoriesDropdownRef}>
                <button
                  onClick={toggleCategoriesDropdown}
                  className="text-gray-600 hover:text-primary flex items-center"
                  aria-label="Toggle categories menu"
                  aria-expanded={isCategoriesDropdownOpen}
                  aria-haspopup="true"
                >
                  Categories <IconChevronDown className="ml-1 w-4 h-4" />
                </button>
                {isCategoriesDropdownOpen && (
                  <div className="absolute left-0 mt-2 w-56 bg-white rounded-md shadow-lg py-1 z-20">
                    {categoriesList.map((category) => (
                      <Link
                        key={category.id}
                        to={`/courses?category=${category.slug}`}
                        onClick={() => setIsCategoriesDropdownOpen(false)}
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-primary-light hover:text-primary"
                      >
                        {category.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
              <SearchBar onSearch={handleSearch} placeholder="Search for anything" />
            </nav>
          </div>

          {/* Right Nav & Mobile Menu Button */}
          <div className="flex items-center space-x-2 sm:space-x-4"> {/* Adjusted spacing for smaller screens */}
            <nav className="hidden md:flex items-center space-x-4"> {/* Adjusted spacing */}
              <Link to="/my-learning" className="text-gray-600 hover:text-primary text-sm sm:text-base">My Learning</Link>
              
              {/* Currency Dropdown */}
              <div className="relative" ref={currencyDropdownRef}>
                <button
                  onClick={toggleCurrencyDropdown}
                  className="text-gray-600 hover:text-primary flex items-center px-2 py-1.5 border border-transparent hover:border-gray-200 rounded-md text-sm sm:text-base"
                  aria-label="Select currency"
                  aria-expanded={isCurrencyDropdownOpen}
                  aria-haspopup="true"
                >
                  <IconGlobeAlt className="w-4 h-4 sm:w-5 sm:h-5 mr-1" />
                  {currentCurrency.code}
                  <IconChevronDown className="ml-1 w-3 h-3 sm:w-4 sm:h-4" />
                </button>
                {isCurrencyDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
                    {supportedCurrencies.map((currency) => (
                      <button
                        key={currency.code}
                        onClick={() => {
                          setCurrency(currency.code);
                          setIsCurrencyDropdownOpen(false);
                        }}
                        className={`w-full text-left block px-4 py-2 text-sm ${
                          currentCurrency.code === currency.code
                            ? 'bg-primary-light text-primary font-semibold'
                            : 'text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        {currency.symbol} - {currency.name} ({currency.code})
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <Link to="/cart" className="text-gray-600 hover:text-primary relative" aria-label={`Shopping cart with ${cartItemCount} items`}>
                <IconShoppingCart className="w-5 h-5 sm:w-6 sm:h-6"/>
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </Link>
              
              {/* Profile Dropdown */}
              <div className="relative" ref={profileDropdownRef}>
                <button
                  onClick={toggleProfileDropdown}
                  className="text-gray-600 hover:text-primary"
                  aria-label="Open user menu"
                  aria-expanded={isProfileDropdownOpen}
                  aria-haspopup="true"
                >
                  <IconUserCircle  className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
                {isProfileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-xl py-1 z-20 border border-gray-200">
                    <div className="px-4 py-3 border-b border-gray-200">
                      <div className="flex items-center space-x-3">
                        <img 
                            src="https://picsum.photos/seed/profileavatar/100/100" 
                            alt="User avatar" 
                            className="w-10 h-10 rounded-full"
                        />
                        <div>
                            <p className="text-sm font-semibold text-gray-800">Pattakan Chanagul</p>
                            <p className="text-xs text-gray-500">pattakanc@hotmail.com</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="py-1">
                      <ProfileDropdownItem to="/my-learning">การเรียนรู้ของฉัน</ProfileDropdownItem>
                      <ProfileDropdownItem to="/cart">รถเข็นของฉัน</ProfileDropdownItem>
                      <ProfileDropdownItem to="/">หลักสูตรที่อยากได้</ProfileDropdownItem>
                      <ProfileDropdownItem to="/">แดชบอร์ดวิทยากร</ProfileDropdownItem>
                    </div>
                    <div className="border-t border-gray-200 py-1">
                        <ProfileDropdownItem to="/" hasBadge>การแจ้งเตือน</ProfileDropdownItem>
                        <ProfileDropdownItem to="/" hasBadge>ข้อความ</ProfileDropdownItem>
                    </div>
                     <div className="border-t border-gray-200 py-1">
                        <ProfileDropdownItem to="/">การตั้งค่าบัญชี</ProfileDropdownItem>
                        <ProfileDropdownItem to="/">วิธีการชำระเงิน</ProfileDropdownItem>
                        <ProfileDropdownItem to="/">การสมัครสมาชิก</ProfileDropdownItem>
                        <ProfileDropdownItem to="/">{APP_NAME} Credits</ProfileDropdownItem>
                        <ProfileDropdownItem to="/">ประวัติการซื้อ</ProfileDropdownItem>
                    </div>
                    <div className="border-t border-gray-200 py-1">
                        <button className="w-full text-left block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex justify-between items-center" onClick={() => setIsProfileDropdownOpen(false)}>
                            <span>ภาษา</span>
                            <span className="flex items-center text-gray-500">
                                ภาษาไทย
                                <IconGlobeAlt className="w-4 h-4 ml-2" />
                            </span>
                        </button>
                    </div>
                    <div className="border-t border-gray-200 py-1">
                        <ProfileDropdownItem to="/">โปรไฟล์สาธารณะ</ProfileDropdownItem>
                        <ProfileDropdownItem to="/">แก้ไขโปรไฟล์</ProfileDropdownItem>
                    </div>
                    <div className="border-t border-gray-200 py-1">
                      <ProfileDropdownItem to="/">ความช่วยเหลือและการสนับสนุน</ProfileDropdownItem>
                      <ProfileDropdownItem onClick={handleSignOut} isButton>ลงชื่อออก</ProfileDropdownItem>
                    </div>
                  </div>
                )}
              </div>
            </nav>
            <button 
              onClick={toggleMobileMenu} 
              className="md:hidden text-gray-600 hover:text-primary"
              aria-label="Toggle mobile menu"
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? <IconX /> : <IconMenu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 py-2 border-t border-gray-200">
            <SearchBar onSearch={(query) => { handleSearch(query); toggleMobileMenu();}} placeholder="Search..." />
            
            {/* Mobile Currency Selector */}
            <div className="py-2 px-1">
                <button
                  onClick={toggleCurrencyDropdown}
                  className="w-full text-left text-gray-700 hover:bg-primary-light hover:text-primary rounded flex justify-between items-center py-2"
                  aria-expanded={isCurrencyDropdownOpen}
                >
                  <span>Currency: {currentCurrency.symbol} ({currentCurrency.code})</span>
                  <IconChevronDown className={`ml-1 w-4 h-4 transition-transform ${isCurrencyDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isCurrencyDropdownOpen && (
                  <div className="mt-1 pl-2">
                    {supportedCurrencies.map((currency) => (
                      <button
                        key={`mobile-${currency.code}`}
                        onClick={() => {
                          setCurrency(currency.code);
                          setIsCurrencyDropdownOpen(false);
                          // toggleMobileMenu(); // Optionally close main mobile menu too
                        }}
                        className={`w-full text-left block py-2 px-1 text-sm ${
                            currentCurrency.code === currency.code
                            ? 'bg-primary-light text-primary font-semibold'
                            : 'text-gray-600 hover:bg-primary-light hover:text-primary'
                        } rounded`}
                      >
                        {currency.symbol} - {currency.name}
                      </button>
                    ))}
                  </div>
                )}
            </div>
            
            <Link to="/my-learning" onClick={toggleMobileMenu} className="block py-2 px-1 text-gray-700 hover:bg-primary-light hover:text-primary rounded">My Learning</Link>
            <div className="py-2 px-1">
                <button
                  onClick={toggleCategoriesDropdown}
                  className="w-full text-left text-gray-700 hover:bg-primary-light hover:text-primary rounded flex justify-between items-center py-2"
                  aria-expanded={isCategoriesDropdownOpen}
                >
                  Categories <IconChevronDown className={`ml-1 w-4 h-4 transition-transform ${isCategoriesDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                {isCategoriesDropdownOpen && (
                  <div className="mt-1 pl-2">
                    {categoriesList.map((category) => (
                      <Link
                        key={category.id}
                        to={`/courses?category=${category.slug}`}
                        onClick={() => { setIsCategoriesDropdownOpen(false); toggleMobileMenu(); }}
                        className="block py-2 px-1 text-sm text-gray-600 hover:bg-primary-light hover:text-primary rounded"
                      >
                        {category.name}
                      </Link>
                    ))}
                  </div>
                )}
            </div>
            <Link to="/cart" onClick={toggleMobileMenu} className="block py-2 px-1 text-gray-700 hover:bg-primary-light hover:text-primary rounded relative">
              Shopping Cart
              {cartItemCount > 0 && (
                  <span className="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-primary-dark bg-primary-light rounded-full">
                    {cartItemCount}
                  </span>
                )}
            </Link>
            <Link to="/" onClick={() => { handleSignOut(); toggleMobileMenu();}} className="block py-2 px-1 text-gray-700 hover:bg-primary-light hover:text-primary rounded">Sign Out</Link>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
