
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Currency {
  code: string;
  symbol: string;
  name: string;
  rate: number; // Rate relative to USD (USD will be 1)
}

export const SUPPORTED_CURRENCIES: Currency[] = [
  { code: 'USD', symbol: '$', name: 'US Dollar', rate: 1 },
  { code: 'THB', symbol: '฿', name: 'Thai Baht', rate: 36.70 }, // Example rate, ensure it's up-to-date for real use
];

interface CurrencyContextType {
  currentCurrency: Currency;
  setCurrency: (currencyCode: string) => void;
  formatPrice: (priceInUsd: number, options?: { includeSymbol?: boolean }) => string;
  supportedCurrencies: Currency[];
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentCurrency, setCurrentCurrencyState] = useState<Currency>(() => {
    try {
      const storedCurrencyCode = localStorage.getItem('rianfastCurrency');
      const foundCurrency = SUPPORTED_CURRENCIES.find(c => c.code === storedCurrencyCode);
      return foundCurrency || SUPPORTED_CURRENCIES.find(c => c.code === 'USD')!; // Default to USD
    } catch (error) {
        console.error("Error reading currency from localStorage:", error);
        return SUPPORTED_CURRENCIES.find(c => c.code === 'USD')!;
    }
  });

  useEffect(() => {
    try {
        localStorage.setItem('rianfastCurrency', currentCurrency.code);
    } catch (error) {
        console.error("Error saving currency to localStorage:", error);
    }
  }, [currentCurrency]);

  const setCurrency = (currencyCode: string) => {
    const newCurrency = SUPPORTED_CURRENCIES.find(c => c.code === currencyCode);
    if (newCurrency) {
      setCurrentCurrencyState(newCurrency);
    }
  };

  const formatPrice = (priceInUsd: number, options: { includeSymbol?: boolean } = { includeSymbol: true }): string => {
    const convertedPrice = priceInUsd * currentCurrency.rate;
    const symbol = options.includeSymbol ? currentCurrency.symbol : '';
    
    const locale = currentCurrency.code === 'THB' ? 'th-TH' : 'en-US';
    const formatterOptions: Intl.NumberFormatOptions = {
      minimumFractionDigits: currentCurrency.code === 'THB' ? 0 : 2,
      maximumFractionDigits: currentCurrency.code === 'THB' ? 0 : 2,
    };

    const formattedNumber = new Intl.NumberFormat(locale, formatterOptions).format(convertedPrice);
    
    return `${symbol}${formattedNumber}`;
  };


  return (
    <CurrencyContext.Provider value={{ currentCurrency, setCurrency, formatPrice, supportedCurrencies: SUPPORTED_CURRENCIES }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = (): CurrencyContextType => {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};
