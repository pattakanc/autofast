
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { Course } from '../types';

// For simplicity, a CartItem is just a Course. Can be extended later if needed (e.g., quantity for other product types)
export type CartItem = Course;

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (course: Course) => void;
  removeFromCart: (courseId: string) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartItemCount: () => number;
  isCourseInCart: (courseId: string) => boolean;
  purchasedCourseIds: string[];
  recordPurchase: (courses: CartItem[]) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const localData = localStorage.getItem('rianfastCart');
      return localData ? JSON.parse(localData) : [];
    } catch (error) {
      console.error("Error loading cart from localStorage:", error);
      return [];
    }
  });

  const [purchasedCourseIds, setPurchasedCourseIds] = useState<string[]>(() => {
    try {
      const localData = localStorage.getItem('rianfastPurchasedCourseIds');
      return localData ? JSON.parse(localData) : [];
    } catch (error) {
      console.error("Error loading purchased course IDs from localStorage:", error);
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('rianfastCart', JSON.stringify(cartItems));
    } catch (error) {
      console.error("Error saving cart to localStorage:", error);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem('rianfastPurchasedCourseIds', JSON.stringify(purchasedCourseIds));
    } catch (error) {
      console.error("Error saving purchased course IDs to localStorage:", error);
    }
  }, [purchasedCourseIds]);

  const addToCart = (course: Course) => {
    setCartItems(prevItems => {
      if (!prevItems.find(item => item.id === course.id)) {
        return [...prevItems, course];
      }
      return prevItems; // Course already in cart
    });
  };

  const removeFromCart = (courseId: string) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== courseId));
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getCartTotal = (): number => {
    return cartItems.reduce((total, item) => total + item.price, 0);
  };

  const getCartItemCount = (): number => {
    return cartItems.length;
  };

  const isCourseInCart = (courseId: string): boolean => {
    return cartItems.some(item => item.id === courseId);
  };

  const recordPurchase = (coursesToPurchase: CartItem[]) => {
    setPurchasedCourseIds(prevIds => {
      const newIds = coursesToPurchase.map(course => course.id);
      const combinedIds = new Set([...prevIds, ...newIds]); // Use Set to handle duplicates
      return Array.from(combinedIds);
    });
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      clearCart,
      getCartTotal,
      getCartItemCount,
      isCourseInCart,
      purchasedCourseIds,
      recordPurchase
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
