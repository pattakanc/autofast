
import type { Course, Instructor, CurriculumSection, Category, Review } from '../types';
import { categoriesList } from '../constants';

const instructors: Instructor[] = [
  { id: 'inst1', name: 'Alice Wonderland', avatarUrl: 'https://picsum.photos/seed/alice/100/100', bio: 'Frontend expert with 10+ years experience building interactive UIs.', rating: 4.9, reviews: 1200, coursesCount: 5 },
  { id: 'inst2', name: 'Bob The Builder', avatarUrl: 'https://picsum.photos/seed/bob/100/100', bio: 'Full-stack developer passionate about backend technologies and DevOps.', rating: 4.8, reviews: 950, coursesCount: 3 },
  { id: 'inst3', name: 'Carol Danvers', avatarUrl: 'https://picsum.photos/seed/carol/100/100', bio: 'Data scientist and ML engineer, making data speak.', rating: 4.9, reviews: 1500, coursesCount: 7 },
  { id: 'inst4', name: 'David Copperfield', avatarUrl: 'https://picsum.photos/seed/david/100/100', bio: 'UX/UI designer focusing on user-centered design principles.', rating: 4.7, reviews: 700, coursesCount: 4 },
];

const mockReviews: Record<string, Review[]> = {
  'react-mastery': [
    { id: 'r1-1', reviewerName: 'John Doe', rating: 5, date: '2024-07-20', comment: 'Absolutely fantastic course! Alice explains complex topics very clearly. Highly recommended for anyone wanting to master React.', reviewerAvatarUrl: 'https://picsum.photos/seed/john_avatar/50/50' },
    { id: 'r1-2', reviewerName: 'Jane Smith', rating: 4, date: '2024-07-18', comment: 'Great content and projects. Some parts were a bit fast-paced, but overall a very valuable learning experience.', reviewerAvatarUrl: 'https://picsum.photos/seed/jane_avatar/50/50' },
    { id: 'r1-3', reviewerName: 'Mike Johnson', rating: 5, date: '2024-07-15', comment: 'This is by far the best React course I have taken. The instructor is knowledgeable and the community is helpful.' },
  ],
  'python-data-science': [
    { id: 'r2-1', reviewerName: 'Emily White', rating: 5, date: '2024-06-25', comment: 'Carol is an amazing instructor! The course is well-structured and covers a lot of ground. The practical examples were very helpful.' },
    { id: 'r2-2', reviewerName: 'Chris Brown', rating: 4, date: '2024-06-22', comment: 'Good course for beginners in data science. I wish there were more advanced topics covered, but it provides a solid foundation.' },
  ],
  'ux-design-fundamentals': [
     { id: 'r3-1', reviewerName: 'Sarah Miller', rating: 5, date: '2024-07-05', comment: 'David makes UX design principles very easy to understand. The assignments were practical and fun. Loved this course!' },
  ]
};


const mockCourses: Course[] = [
  {
    id: 'react-mastery',
    title: 'React Mastery: From Zero to Hero',
    subtitle: 'The ultimate guide to mastering React, Redux, and modern JavaScript.',
    instructor: instructors[0],
    description: 'Dive deep into React, learning core concepts, state management with Redux, hooks, context API, and best practices for building scalable applications.',
    longDescription: 'This comprehensive course covers everything you need to know to become a proficient React developer. We start with the basics of JSX and components, move through advanced state management techniques, and explore routing, testing, and deployment. By the end, you will have built several real-world projects.',
    price: 89.99,
    originalPrice: 199.99,
    rating: 4.8,
    reviewsCount: 15230,
    thumbnailUrl: 'https://picsum.photos/seed/react-mastery/600/400',
    category: 'Web Development',
    tags: ['React', 'Redux', 'JavaScript', 'Frontend'],
    level: 'All Levels',
    duration: '45 hours',
    studentsEnrolled: 75000,
    lastUpdated: '2024-07-15',
    whatYouWillLearn: [
      'Build rich, interactive UIs with React.',
      'Manage complex application state using Redux and Context API.',
      'Understand and use React Hooks effectively.',
      'Test your React applications with Jest and React Testing Library.',
      'Deploy React applications to various platforms.',
    ],
    requirements: [
      'Basic understanding of HTML, CSS, and JavaScript (ES6+).',
      'A computer with Node.js and npm installed.',
    ],
    curriculum: [
      { id: 's1', title: 'Module 1: Introduction to React', lessons: [
          { id: 'l1-1', title: 'What is React?', duration: '12min', type: 'video', previewable: true, contentUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm' },
          { id: 'l1-2', title: 'Setting up Your Environment', duration: '20min', type: 'video' },
          { id: 'l1-3', title: 'Understanding JSX', duration: '15min', type: 'video' },
        ]
      },
      { id: 's2', title: 'Module 2: Components and Props', lessons: [
          { id: 'l2-1', title: 'Functional vs Class Components', duration: '18min', type: 'video' },
          { id: 'l2-2', title: 'Working with Props', duration: '22min', type: 'video' },
          { id: 'l2-3', title: 'Component Composition', duration: '17min', type: 'article' },
        ]
      },
      { id: 's3', title: 'Module 3: State and Lifecycle', lessons: [
          { id: 'l3-1', title: 'Introduction to State', duration: '25min', type: 'video', previewable: true, contentText: 'State is a fundamental concept in React...' },
          { id: 'l3-2', title: 'Lifecycle Methods (Class Components)', duration: '30min', type: 'video' },
          { id: 'l3-3', title: 'Handling Events', duration: '20min', type: 'video' },
        ]
      },
    ],
    language: 'English',
    certificate: true,
    reviews: mockReviews['react-mastery'],
  },
  {
    id: 'python-data-science',
    title: 'Python for Data Science & Machine Learning Bootcamp',
    subtitle: 'Learn Python for Data Science, Pandas, NumPy, Matplotlib, Scikit-learn and more!',
    instructor: instructors[2],
    description: 'A comprehensive course to learn Python and its application in data science and machine learning. Covers data analysis, visualization, and building ML models.',
    price: 99.99,
    originalPrice: 249.99,
    rating: 4.7,
    reviewsCount: 22500,
    thumbnailUrl: 'https://picsum.photos/seed/python-ds/600/400',
    category: 'Data Science',
    tags: ['Python', 'Data Analysis', 'Machine Learning', 'Pandas', 'NumPy'],
    level: 'Beginner',
    duration: '30 hours',
    studentsEnrolled: 120000,
    lastUpdated: '2024-06-20',
    whatYouWillLearn: [
        'Master Python programming for data science.',
        'Use Pandas for data manipulation and analysis.',
        'Create insightful visualizations with Matplotlib and Seaborn.',
        'Implement machine learning algorithms with Scikit-learn.',
        'Understand the fundamentals of data preprocessing and feature engineering.',
        'Build and evaluate predictive models for classification and regression tasks.'
    ],
    requirements: ['No prior programming experience needed.', 'A computer with internet access and willingness to learn!'],
    curriculum: [
      { id: 'ds-s1', title: 'Chapter 1: Introduction to Python for Data Science', lessons: [
          { id: 'ds-l1-1', title: 'Course Overview & Setup', duration: '10min', type: 'video', previewable: true, contentUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm' },
          { id: 'ds-l1-2', title: 'Python Basics: Variables, Data Types', duration: '25min', type: 'video' },
          { id: 'ds-l1-3', title: 'Python Basics: Operators & Expressions', duration: '20min', type: 'video' },
          { id: 'ds-l1-4', title: 'Control Flow: If/Else Statements', duration: '18min', type: 'video' },
          { id: 'ds-l1-5', title: 'Control Flow: Loops (For & While)', duration: '22min', type: 'video' },
        ]
      },
      { id: 'ds-s2', title: 'Chapter 2: Python Data Structures', lessons: [
          { id: 'ds-l2-1', title: 'Lists and List Operations', duration: '20min', type: 'video' },
          { id: 'ds-l2-2', title: 'Tuples and Their Uses', duration: '15min', type: 'video' },
          { id: 'ds-l2-3', title: 'Dictionaries and Key-Value Pairs', duration: '25min', type: 'video' },
          { id: 'ds-l2-4', title: 'Sets and Set Operations', duration: '18min', type: 'article', contentText: "Understanding sets in Python..." },
        ]
      },
      { id: 'ds-s3', title: 'Chapter 3: Functions and Modules in Python', lessons: [
          { id: 'ds-l3-1', title: 'Defining and Calling Functions', duration: '22min', type: 'video' },
          { id: 'ds-l3-2', title: 'Function Arguments and Return Values', duration: '20min', type: 'video' },
          { id: 'ds-l3-3', title: 'Lambda Functions (Anonymous Functions)', duration: '15min', type: 'video' },
          { id: 'ds-l3-4', title: 'Importing and Using Modules', duration: '18min', type: 'video' },
        ]
      },
      { id: 'ds-s4', title: 'Chapter 4: NumPy for Numerical Computing', lessons: [
          { id: 'ds-l4-1', title: 'Introduction to NumPy Arrays', duration: '20min', type: 'video', previewable: true, contentText: "NumPy arrays are fundamental..." },
          { id: 'ds-l4-2', title: 'Array Indexing and Slicing', duration: '25min', type: 'video' },
          { id: 'ds-l4-3', title: 'Array Operations and Universal Functions (ufuncs)', duration: '30min', type: 'video' },
          { id: 'ds-l4-4', title: 'Statistical Operations with NumPy', duration: '22min', type: 'video' },
        ]
      },
      { id: 'ds-s5', title: 'Chapter 5: Pandas for Data Manipulation', lessons: [
          { id: 'ds-l5-1', title: 'Introduction to Pandas Series', duration: '18min', type: 'video' },
          { id: 'ds-l5-2', title: 'Introduction to Pandas DataFrames', duration: '25min', type: 'video' },
          { id: 'ds-l5-3', title: 'Reading and Writing Data (CSV, Excel)', duration: '20min', type: 'video' },
          { id: 'ds-l5-4', title: 'Data Selection and Indexing (loc, iloc)', duration: '30min', type: 'video' },
          { id: 'ds-l5-5', title: 'Handling Missing Data', duration: '22min', type: 'video' },
          { id: 'ds-l5-6', title: 'Grouping and Aggregation (groupby)', duration: '28min', type: 'video' },
          { id: 'ds-l5-7', title: 'Merging, Joining, and Concatenating DataFrames', duration: '25min', type: 'video' },
        ]
      },
      { id: 'ds-s6', title: 'Chapter 6: Matplotlib for Data Visualization', lessons: [
          { id: 'ds-l6-1', title: 'Basic Plotting with Matplotlib', duration: '20min', type: 'video' },
          { id: 'ds-l6-2', title: 'Customizing Plots: Labels, Titles, Colors', duration: '25min', type: 'video' },
          { id: 'ds-l6-3', title: 'Different Plot Types: Line, Bar, Scatter, Histogram', duration: '30min', type: 'video' },
          { id: 'ds-l6-4', title: 'Subplots and Figure Management', duration: '22min', type: 'article', contentText: 'Creating multiple plots...' },
        ]
      },
      { id: 'ds-s7', title: 'Chapter 7: Seaborn for Statistical Visualization', lessons: [
          { id: 'ds-l7-1', title: 'Introduction to Seaborn', duration: '15min', type: 'video' },
          { id: 'ds-l7-2', title: 'Distribution Plots (distplot, jointplot, pairplot)', duration: '28min', type: 'video' },
          { id: 'ds-l7-3', title: 'Categorical Plots (barplot, countplot, boxplot, violinplot)', duration: '30min', type: 'video' },
          { id: 'ds-l7-4', title: 'Matrix Plots (heatmap, clustermap)', duration: '20min', type: 'video' },
        ]
      },
      { id: 'ds-s8', title: 'Chapter 8: Introduction to Machine Learning with Scikit-learn', lessons: [
          { id: 'ds-l8-1', title: 'What is Machine Learning?', duration: '15min', type: 'video', previewable: true, contentText: "An overview of ML concepts." },
          { id: 'ds-l8-2', title: 'Supervised vs Unsupervised Learning', duration: '20min', type: 'video' },
          { id: 'ds-l8-3', title: 'The Scikit-learn API: Estimators, Predictors, Transformers', duration: '25min', type: 'video' },
          { id: 'ds-l8-4', title: 'Data Preprocessing: Scaling and Normalization', duration: '22min', type: 'video' },
          { id: 'ds-l8-5', title: 'Splitting Data: Training and Testing Sets', duration: '18min', type: 'video' },
        ]
      },
      { id: 'ds-s9', title: 'Chapter 9: Supervised Learning - Regression', lessons: [
          { id: 'ds-l9-1', title: 'Linear Regression: Theory and Implementation', duration: '30min', type: 'video' },
          { id: 'ds-l9-2', title: 'Evaluating Regression Models (MAE, MSE, RMSE, R-squared)', duration: '25min', type: 'video' },
          { id: 'ds-l9-3', title: 'Polynomial Regression', duration: '20min', type: 'video' },
          { id: 'ds-l9-4', title: 'Project: Predicting House Prices (Regression)', duration: '45min', type: 'quiz' },
        ]
      },
      { id: 'ds-s10', title: 'Chapter 10: Supervised Learning - Classification', lessons: [
          { id: 'ds-l10-1', title: 'Logistic Regression: Theory and Implementation', duration: '30min', type: 'video' },
          { id: 'ds-l10-2', title: 'K-Nearest Neighbors (KNN)', duration: '28min', type: 'video' },
          { id: 'ds-l10-3', title: 'Support Vector Machines (SVM)', duration: '35min', type: 'video' },
          { id: 'ds-l10-4', title: 'Decision Trees and Random Forests', duration: '40min', type: 'video' },
          { id: 'ds-l10-5', title: 'Evaluating Classification Models (Accuracy, Precision, Recall, F1-score, Confusion Matrix)', duration: '30min', type: 'video' },
          { id: 'ds-l10-6', title: 'Project: Iris Flower Classification', duration: '45min', type: 'quiz' },
        ]
      },
       { id: 'ds-s11', title: 'Chapter 11: Next Steps & Further Learning', lessons: [
          { id: 'ds-l11-1', title: 'Course Recap and Key Takeaways', duration: '15min', type: 'video' },
          { id: 'ds-l11-2', title: 'Further Learning Resources and Career Paths', duration: '20min', type: 'article', contentText: 'Where to go from here...' },
        ]
      }
    ],
    language: 'English',
    certificate: true,
    reviews: mockReviews['python-data-science'],
  },
  {
    id: 'ux-design-fundamentals',
    title: 'UX Design Fundamentals: User-Centered Design',
    subtitle: 'Learn the basics of UX design, from research to prototyping and testing.',
    instructor: instructors[3],
    description: 'An introductory course to UX design principles, methodologies, and tools. Learn how to create user-friendly digital products.',
    price: 79.99,
    rating: 4.9,
    reviewsCount: 8750,
    thumbnailUrl: 'https://picsum.photos/seed/ux-design/600/400',
    category: 'Design',
    tags: ['UX Design', 'UI Design', 'User Research', 'Prototyping'],
    level: 'Beginner',
    duration: '20 hours',
    studentsEnrolled: 45000,
    lastUpdated: '2024-07-01',
    whatYouWillLearn: [
        'Understand core UX design principles.',
        'Conduct user research and create personas.',
        'Design wireframes and interactive prototypes.',
        'Perform usability testing and iterate on designs.',
    ],
    requirements: ['An interest in design and problem-solving.'],
    curriculum: [
      { id: 's1-ux', title: 'Section 1: Introduction to UX', lessons: [{ id: 'l1-ux', title: 'What is UX Design?', duration: '8min', type: 'article', previewable: true, contentText: 'UX Design is all about creating products that provide meaningful and relevant experiences to users...' }] },
    ],
    language: 'English',
    certificate: false,
    reviews: mockReviews['ux-design-fundamentals'],
  },
  {
    id: 'javascript-deep-dive',
    title: 'JavaScript: The Advanced Concepts',
    subtitle: 'Master advanced JavaScript concepts: closures, prototypal inheritance, async JS, and more.',
    instructor: instructors[0],
    description: 'Go beyond the basics and master the tricky parts of JavaScript. This course is for developers who want a deep understanding of the language.',
    price: 69.99,
    originalPrice: 149.99,
    rating: 4.6,
    reviewsCount: 11200,
    thumbnailUrl: 'https://picsum.photos/seed/js-advanced/600/400',
    category: 'Web Development',
    tags: ['JavaScript', 'ESNext', 'Async Programming', 'Frontend', 'Backend'],
    level: 'Intermediate',
    duration: '25 hours',
    studentsEnrolled: 35000,
    lastUpdated: '2024-05-10',
    whatYouWillLearn: [
        'Understand closures, scope, and execution context.',
        'Master prototypal inheritance and ES6 classes.',
        'Handle asynchronous operations with Promises and Async/Await.',
        'Learn about event loop, memory management, and performance optimization.',
    ],
    requirements: ['Solid understanding of JavaScript fundamentals.'],
    language: 'English',
    certificate: true,
    // No reviews for this one yet for variety
  },
   {
    id: 'fullstack-web-dev',
    title: 'The Complete Fullstack Web Developer Bootcamp',
    subtitle: 'Learn HTML, CSS, JavaScript, Node.js, React, MongoDB, and more!',
    instructor: instructors[1],
    description: 'Become a full-stack web developer with just one course. HTML, CSS, Javascript, Node, React, MongoDB and more!',
    price: 109.99,
    originalPrice: 299.99,
    rating: 4.5,
    reviewsCount: 18500,
    thumbnailUrl: 'https://picsum.photos/seed/fullstack/600/400',
    category: 'Web Development',
    tags: ['Fullstack', 'HTML', 'CSS', 'JavaScript', 'Node.js', 'React', 'MongoDB'],
    level: 'All Levels',
    duration: '55 hours',
    studentsEnrolled: 95000,
    lastUpdated: '2024-07-10',
    whatYouWillLearn: [
      'Build beautiful responsive websites with HTML and CSS.',
      'Master JavaScript and its asynchronous nature.',
      'Develop backend applications with Node.js and Express.',
      'Create dynamic frontend applications with React.',
      'Work with MongoDB and Mongoose for database operations.',
    ],
    requirements: ['A computer with internet access.', 'No prior coding experience required.'],
    curriculum: [
       { id: 's1-fs', title: 'Module 1: Frontend Basics', lessons: [{ id: 'l1-1-fs', title: 'Introduction to HTML', duration: '10min', type: 'video', previewable: true, contentUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm' },] },
       { id: 's2-fs', title: 'Module 2: Backend with Node.js', lessons: [{ id: 'l2-1-fs', title: 'Setting up Node.js', duration: '15min', type: 'video' },] },
    ],
    language: 'English',
    certificate: true,
    reviews: [ // Adding a few reviews for this course
        { id: 'r4-1', reviewerName: 'Tech Learner', rating: 5, date: '2024-07-12', comment: 'Covers a huge amount of material. Great value for money and Bob is an engaging instructor.'},
        { id: 'r4-2', reviewerName: 'Code Newbie', rating: 4, date: '2024-07-11', comment: 'It is indeed a full bootcamp. Can be overwhelming at times but stick with it!'}
    ]
  },
  {
    id: 'ios-swift-development',
    title: 'iOS & Swift - The Complete iOS App Development Bootcamp',
    subtitle: 'From beginner to iOS App Developer with Just One Course! With Swift and Xcode.',
    instructor: instructors[1], 
    description: 'Learn to code in Swift and build a portfolio of iOS apps for iPhone and iPad. Includes ARKit, CoreML, and more.',
    price: 94.99,
    rating: 4.8,
    reviewsCount: 14300,
    thumbnailUrl: 'https://picsum.photos/seed/ios-swift/600/400',
    category: 'Mobile Development',
    tags: ['iOS', 'Swift', 'Xcode', 'Mobile App Development'],
    level: 'All Levels',
    duration: '60 hours',
    studentsEnrolled: 65000,
    lastUpdated: '2024-06-01',
    whatYouWillLearn: [
      'Develop any iOS app you want.',
      'Master Swift programming language.',
      'Build apps with CoreML for machine learning and ARKit for augmented reality.',
      'Understand iOS design patterns and best practices.',
    ],
    requirements: ['A Mac computer capable of running Xcode.', 'No prior programming experience needed.'],
    curriculum: [
      { id: 's1-ios', title: 'Module 1: Introduction to Swift', lessons: [{ id: 'l1-1-ios', title: 'Swift Basics', duration: '15min', type: 'video', previewable: true, contentUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm' }] },
    ],
    language: 'English',
    certificate: true,
    // No reviews for this one yet
  }
];

export const getCourses = async (categorySlug?: string, searchTerm?: string): Promise<Course[]> => {
  await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API delay
  let filteredCourses = mockCourses;
  if (categorySlug) {
    const category = categoriesList.find(c => c.slug === categorySlug);
    if (category) {
      filteredCourses = filteredCourses.filter(course => course.category === category.name);
    }
  }
  if (searchTerm) {
    const lowerSearchTerm = searchTerm.toLowerCase();
    filteredCourses = filteredCourses.filter(course => 
      course.title.toLowerCase().includes(lowerSearchTerm) ||
      course.description.toLowerCase().includes(lowerSearchTerm) ||
      (course.tags && course.tags.some(tag => tag.toLowerCase().includes(lowerSearchTerm)))
    );
  }
  return filteredCourses;
};

export const getCourseById = async (id: string): Promise<Course | undefined> => {
  await new Promise(resolve => setTimeout(resolve, 300)); // Simulate API delay
  return mockCourses.find(course => course.id === id);
};

export const getFeaturedCourses = async (): Promise<Course[]> => {
  await new Promise(resolve => setTimeout(resolve, 200));
  return mockCourses.slice(0, 4); // Example: first 4 courses are featured
};

export const getCategories = async (): Promise<Category[]> => {
  await new Promise(resolve => setTimeout(resolve, 100));
  return categoriesList;
};

export const getCoursesByInstructor = async (instructorId: string): Promise<Course[]> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  return mockCourses.filter(course => course.instructor.id === instructorId);
};
